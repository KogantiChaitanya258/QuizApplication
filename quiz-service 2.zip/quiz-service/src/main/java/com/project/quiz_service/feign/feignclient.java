package com.project.quiz_service.feign;

public @interface feignclient {

}
