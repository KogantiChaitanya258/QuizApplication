package com.project.quiz_service.controller;

public class QuizDto {

}
